<template>
  <div>
    问答
  </div>
</template>

<script>
export default {
  name: 'qaIndex',
  data () {
    return {

    }
  },
  methods: {

  }
}
</script>

<style lang="less" scoped>

</style>
