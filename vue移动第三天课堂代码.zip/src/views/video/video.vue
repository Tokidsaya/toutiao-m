<template>
  <div>
    视频
  </div>
</template>

<script>
export default {
  name: 'videoIndex',
  data () {
    return {

    }
  },
  methods: {

  }
}
</script>

<style lang="less" scoped>

</style>
