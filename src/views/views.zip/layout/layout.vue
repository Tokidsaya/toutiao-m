<template>
  <div>
    <!-- 二级路由组件 -->
    <router-view></router-view>

    <!-- 底部标签导航 tabbar -->
    <van-tabbar route>
      <van-tabbar-item replace to="/home" icon="home-o">首页</van-tabbar-item>
      <van-tabbar-item replace to="/qa" icon="home-o">问答</van-tabbar-item>
      <van-tabbar-item replace to="/video" icon="home-o">视频</van-tabbar-item>
      <van-tabbar-item replace to="/my" icon="search">我的</van-tabbar-item>
    </van-tabbar>
  </div>
</template>

<script>
export default {
  name: 'LayoutIndex',
  data () {
    return {

    }
  },
  methods: {

  }
}
</script>

<style lang="less" scoped>

</style>
