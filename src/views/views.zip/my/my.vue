<template>
  <div>
    我的
  </div>
</template>

<script>
export default {
  name: 'MyIndex',
  data () {
    return {

    }
  },
  methods: {

  }
}
</script>

<style lang="less" scoped>

</style>
